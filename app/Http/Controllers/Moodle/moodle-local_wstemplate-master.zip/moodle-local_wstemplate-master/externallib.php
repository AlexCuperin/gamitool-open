<?php

// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * External Web Service Template
 *
 * @package    localwstemplate
 * @copyright  2011 Moodle Pty Ltd (http://moodle.com)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require_once($CFG->libdir . "/externallib.php");
//require_once('/var/www/html/moodle/local/wstemplate/purge_caches.php');

class local_wstemplate_external extends external_api {

    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function hello_world_parameters() {
        return new external_function_parameters(
                array(
                    'course_id' => new external_value(PARAM_INT, 'course id', VALUE_DEFAULT, 1),
                    'section_name' => new external_value(PARAM_TEXT, 'nombre de la sección', VALUE_DEFAULT, 'Course Rewards'),
                    'section_description' => new external_value(PARAM_TEXT, 'descripción de la sección', VALUE_DEFAULT, 'Course Rewards'),
                    'tool_url' => new external_value(PARAM_TEXT, 'url de la herramienta', VALUE_DEFAULT, ''),
                    'resource_key' => new external_value(PARAM_TEXT, 'resource key', VALUE_DEFAULT, ''),
                    'password' => new external_value(PARAM_TEXT, 'shared secret', VALUE_DEFAULT, ''),)
        );
    }

    /**
     * Returns welcome message
     * @return string welcome message
     */
    public static function hello_world($course_id, $section_name, $section_description, $tool_url, $resource_key, $password) {
        global $USER, $DB;

        //Parameter validation
        //REQUIRED
        $params = self::validate_parameters(self::hello_world_parameters(),
                array(  'course_id' => $course_id,
                        'section_name' => $section_name,
                        'section_description' => $section_description,
                        'tool_url' => $tool_url,
                        'resource_key' => $resource_key,
                        'password' => $password));

        //Context validation
        //OPTIONAL but in most web service it should present
        //$context = get_context_instance(CONTEXT_USER, $USER->id);
        $context = context_user::instance($USER->id);;
        self::validate_context($context);

        //Capability checking
        //OPTIONAL but in most web service it should present
        if (!has_capability('moodle/user:viewdetails', $context)) {
            throw new moodle_exception('cannotviewprofile');
        }

        //$data = $DB->get_record($section_name, array('id'=>$course_id));
        //return serialize($data);

        // 1. Creamos la herramienta LTI
        $new_lti =
            [   //'id' => ,
                'course' => $course_id,
                //'section' => 0,
                'name' => $section_name,
                'intro' => $section_description,
                'introformat' => 1,
                //'timecreated' => ,
                //'timemodified' => ,
                'typeid' => 0,
                'toolurl' => $tool_url,
                'securetoolurl' => '',
                'instructorchoicesendname' => 1,
                'instructorchoicesendemailaddr' => 1,
                'instructorchoiceallowroster' => 0,
                'instructorchoiceallowsetting' => 0,
                'instructorcustomparameters' => 0,
                'instructorchoiceacceptgrades' => 0,
                'grade' => 0,
                'launchcontainer' => 1,
                'resourcekey' => $resource_key,
                'password' => $password,
                'debuglaunch' => 0,
                'showtitlelaunch' => 1,
                'showdescriptionlaunch' => 0,
                //'servicesalt' => 5baf512b6f3cb5.42604083,
                'icon' => 0,
                'secureicon' => 0];

        $tool_id = $DB->insert_record('lti', $new_lti, true, false);

        // 2. Creamos la sección
        /*$new_section =
            [
                //'id' => ,
                'course' => $course_id,
                'section' => 5,
                'name' => 'NEW SECTION',
                'summary' => $section_description,
                'summaryformat' => 1,
                'sequence' => "",
                'visible' => 1,
                'availability' => ""
                //'timemodified'=>
        ];*/

        //$section_id = $DB->insert_record('course_sections', $new_section, true, false);

        /*$new_format_option =
            [
                //'id' => 4
                'courseid' => $course_id,
                'format' => 'weeks',
                'sectionid' => 0,
                'name' => 'numsections',
                'value' => '5'
        ];

        $format_id = $DB->insert_record('course_format_options', $new_format_option, true, false);*/

        // 3. Creamos la actividad
        $new_activity = [
            //'id'
            'course' => $course_id,
            'module' => 14,
            'instance' => $tool_id,
            'section' => 0,
            //'idnumber' =>
            //'added' => 1538216235
            'score' => 0,
            'indent' => 0,
            'visible' => 1,
            'visibleoncoursepage' => 1,
            'visibleold' => 1,
            'groupmode' => 0,
            'groupingid' => 0,
            'completion' => 0,
            //'completiongradeitemnumber' =>
            'completionview' => 0,
            'completionexpected' => 0,
            'showdescription' => 1,
            'availability' => "",
            'deletioninprogress' => 0
        ];

        $activity_id = $DB->insert_record('course_modules', $new_activity, true, false);

        // 4. Actualizamos la secuencia de la sección

        $created_section = $DB->get_record('course_sections', array('course'=>$course_id, 'section' => 0));
        if($created_section->sequence) {$created_section->sequence = $activity_id . "," . $created_section->sequence;}
        else {$created_section->sequence = $activity_id . "";}
        $result = $DB->update_record('course_sections', $created_section, false);

        // 5. Actualizamos caché y módulos
        //newmodule_update_instance($activity_id);
        rebuild_course_cache($course_id, true);
        return 'ok';

    }

    /**
     * Returns description of method result value
     * @return external_description
     */
    public static function hello_world_returns() {
        return new external_value(PARAM_TEXT, 'ok if ok');
    }



}
